write-host "UNKNOWN: Everything is not going to be fine!"
exit 3
