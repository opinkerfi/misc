File name:    README.txt
Revision:     HEAD
Date:         December 5, 2008
Author:       Dr. Dave Blunt at GroundWork Open Source Inc. (dblunt@groundworkopensource.com)
=============================================================================================

This file is deprecated.  Please use 'WMI agentless plugins.pdf'.